package com.example.deepthought.ViewModels

import androidx.lifecycle.ViewModel

class ProjectViewModel : ViewModel(){
}